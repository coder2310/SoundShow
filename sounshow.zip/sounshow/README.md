# SoundShow Source Code
* To run:
    - pip3 install -r requirments.txt
    - export FLASK_ENV=development
    - python3 app.py
