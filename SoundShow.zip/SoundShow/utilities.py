# This will be used for usefull functions like
# hashing and password strength
import hashlib
import os
import string
import re


def hash_password(password):
    return hashlib.sha256(password.encode("utf-8")).hexdigest()

def valid_username(user_name):
    '''Each username should be at least 6 characters long, will convert
    all to lowercase when entered, should also have at least number
    also no special characters'''
    if len(user_name) < 6:
        return False
    digit_count = 0
    for char in user_name:
        if char in string.punctuation:
            return False
        if char.isdigit():
            digit_count += 1
    return digit_count # If its anything other then 0 it will be true, if 0 its false

def valid_email(email):
    regex = '^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$'
    if(re.search(regex,email)):  
        return True
    return False
    # if len(email)>7:
    #     if re.fullmatch("^.+@([?)[a-zA-Z0-9-.]+.([a-zA-Z]{2,3}|[0-9]{1,3})(]?)$", email) != None:
    #         return True
    #     return False
        

def valid_password(pass_word):
    '''Passwords should be between 8 and 12 characters long.
    Should have at least one uppercase one number and one special 
    character in the set (!,$,@,#, &)
    '''
    if len(pass_word) > 12 or len(pass_word) < 8:
        return False
    #special_chars = {'!', '@', '#', '$', '&'}
    upper = 0
    digit = 0
    special = 0
    for chars in pass_word:
        if chars in string.ascii_uppercase:
            upper += 1
        elif chars in string.digits:
            digit += 1
        elif chars in string.punctuation:
            special += 1
    if upper and digit and special:
        return True
    return False

