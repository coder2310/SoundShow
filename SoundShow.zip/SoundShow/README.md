# SoundShow Source Code
* To run:
    - pip3 -r requirments.txt
    - python3 main.py
